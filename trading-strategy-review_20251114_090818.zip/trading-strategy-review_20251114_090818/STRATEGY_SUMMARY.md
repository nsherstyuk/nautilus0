# Trading Strategy Summary

## Overview
Multi-timeframe moving average crossover strategy for forex trading (EUR/USD, GBP/USD, USD/JPY)
with extensive signal filtering and adaptive risk management.

## Core Components

### 1. Signal Generation
- **Base**: Moving average crossover (Fast: 40-46, Slow: 260-297)
- **Primary Timeframe**: 15-minute bars
- **Crossover Threshold**: 0.35 pips minimum separation

### 2. Multi-Timeframe Filters (96.2% rejection rate)
- **DMI (Directional Movement Index)**: Period 10 on 15-min bars
- **Stochastic**: K=19, D=3, thresholds 20/80, max 3 bars since crossing
- **RSI**: Period 14, overbought 70, oversold 30 (optional)
- **ATR**: Period 14, minimum strength 0.8 (optional)
- **Trend Filter**: EMA alignment check (optional)
- **Volume Filter**: 1.2x average volume required (optional)

### 3. Time-Based Filters
- **Excluded Hours**: Configurable by weekday (flat or per-weekday mode)
- **Purpose**: Avoid low-liquidity periods and news events

### 4. Risk Management
- **Position Sizing**: Fixed $100k per trade (1 standard lot)
- **Stop Loss**: 35 pips (adaptive ATR-based available)
- **Take Profit**: 50 pips (adaptive ATR-based available)
- **Trailing Stop**: Activates at 22 pips, trails by 12 pips
- **Adaptive Mode**: ATR multipliers with regime detection

### 5. Regime Detection (Optional)
- **Method**: ADX-based (threshold 25 for trending)
- **Effect**: Multiplies TP/SL based on market regime
- **Trending**: 1.5x TP, 0.8x SL (wider targets, tighter stops)
- **Ranging**: 0.8x TP, 1.2x SL (tighter targets, wider stops)

## Performance Metrics (EUR/USD Jan 2024 - Oct 2025)

### Returns
- **Total PnL**: $14,845.92
- **Unleveraged ROI**: 14.85% over 640 days (~8.5% annual)
- **Leveraged ROI**: 339% annual (with 40x leverage)

### Trade Statistics
- **Total Trades**: 195
- **Win Rate**: 35.9%
- **Win/Loss Ratio**: 3.73:1
- **Average Trade**: $76.13 expectancy
- **Frequency**: 2.1 trades/week, 8.9 trades/month

### Signal Quality
- **Total Signals**: 5,137
- **Accepted**: 195 (3.8%)
- **Rejected**: 4,942 (96.2%)

### Monthly Performance
- **Positive Months**: 15/22 (68.2%)
- **Negative Months**: 7/22 (31.8%)
- **Best Month**: +$3,157 (Sep 2025)
- **Worst Month**: -$704 (Jan 2024, 7.1% win rate)
- **Longest Gap**: 21 days between trades

### Risk Metrics
- **Max Losing Streak**: 2 consecutive months
- **Negative Month Win Rate**: Average 19.3%
- **Positive Month Win Rate**: Average 45.3%

## Technical Stack
- **Platform**: NautilusTrader 1.221.0
- **Broker**: Interactive Brokers (IBKR)
- **Language**: Python 3.12
- **Data**: 15-minute OHLC bars from IBKR

## Current Development Focus
1. Multi-pair diversification (GBP/USD, USD/JPY)
2. Pair rotation logic to avoid negative months
3. Circuit breaker protection (<20% win rate triggers pause)
4. Historical backfill for instant strategy warmup

## Key Files
- `strategies/moving_average_crossover.py` - Main strategy logic (1,500+ lines)
- `config/live_config.py` - Configuration management
- `live/run_live.py` - Live trading orchestration
- `logs/backtest_results/EUR-USD_20251113_195050/` - Latest backtest results
