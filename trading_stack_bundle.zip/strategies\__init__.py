"""Strategy package."""
